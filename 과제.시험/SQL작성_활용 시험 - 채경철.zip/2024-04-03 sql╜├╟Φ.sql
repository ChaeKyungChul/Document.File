/*---------------2024-04-03---------*/
create database systemtable;
use systemtable;
/*----------학과테이블생성---------*/
CREATE TABLE `systemtable`.`department` (
  `department_id` INT NOT NULL,
  `department_name` VARCHAR(45) NULL);
  /*----------학과테이블조회---------*/
select * from department ;

/*---------교수테이블생성----------*/
CREATE TABLE `systemtable`.`professo` (
  `professor_id` INT NOT NULL,
  `professor_name` VARCHAR(45) NULL,
  `department_id` INT NULL,
  PRIMARY KEY (`professor_id`));
/*--------교수테이블조회-----------*/
select * from professo ;


/*---------개설과목 테이블 생성----------*/
CREATE TABLE `systemtable`.`course` (
  `course_id` INT NOT NULL,
  `course_name` VARCHAR(45) NULL,
  `professor_id` INT NULL,
  `start_date` DATE NULL,
  `end_date` DATE NULL,
  PRIMARY KEY (`course_id`));
/*---------개설과목 조회--------*/
select * from course ;

/*-----------수강테이블생성--------*/
CREATE TABLE `systemtable`.`student_course` (
  `student_id` INT NOT NULL,
  `course_id` INT NULL,
  PRIMARY KEY (`student_id`));
/*----------수강테이블조회---------*/
select * from student_course ;

/*--------학생테이블생성-----------*/
CREATE TABLE `systemtable`.`student` (
  `student_id` INT NOT NULL,
  `student_name` VARCHAR(45) NULL,
  `height` DOUBLE NULL,
  `department_id` INT NULL,
  PRIMARY KEY (`student_id`));
/*--------학생테이블조회-----------*/
select * from student ;

/************학생.수강테이블 조인검색*********/
SELECT * FROM student INNER JOIN student_courses ON student.student_id = student_courses.student_id;
/************뷰테이블 생성 *********/
CREATE VIEW student_view AS SELECT student_id, student_nameFROM student;
/************뷰테이블 조회 *********/
select * from student_view ;

/***********기본키 외래키설정*******/
CREATE TABLE IF NOT EXISTS `mydb`.`Student_Coures` (
  `student_id` INT NOT NULL,
  `course_id` INT NULL,
  `Course_course_id` INT NOT NULL,
  `Student_student_id` INT NOT NULL,
  PRIMARY KEY (`student_id`),
  INDEX `fk_Student_Coures_Course1_idx` (`Course_course_id` ASC) VISIBLE,
  INDEX `fk_Student_Coures_Student1_idx` (`Student_student_id` ASC) VISIBLE,
  CONSTRAINT `fk_Student_Coures_Course1`
    FOREIGN KEY (`Course_course_id`)
    REFERENCES `mydb`.`Course` (`course_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_Student_Coures_Student1`
    FOREIGN KEY (`Student_student_id`)
    REFERENCES `mydb`.`Student` (`student_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;
SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
