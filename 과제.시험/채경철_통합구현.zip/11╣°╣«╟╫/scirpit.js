function calculateAverage() {
    var table = document.getElementById('ageTable');
    var rows = table.getElementsByTagName('tr');
    var totalAge = 0;
    for (var i = 1; i < rows.length - 1; i++) {
      var age = parseInt(rows[i].getElementsByTagName('td')[2].innerText);
      totalAge += age;
    }
    var averageAge = totalAge / (rows.length - 2);
    document.getElementById('averageCell').innerText = averageAge.toFixed(2) + '세';
  }