function checkAll(source) {
    let checkboxes = document.querySelectorAll('input[name="food"], input[name^="sub"]');
    checkboxes.forEach(checkbox => checkbox.checked = source.checked);
  }

  function checkSub(source, className) {
    let subCheckboxes = document.querySelectorAll(`.${className}`);
    subCheckboxes.forEach(checkbox => checkbox.checked = source.checked);
  }