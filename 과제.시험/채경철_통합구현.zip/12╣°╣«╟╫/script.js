document.addEventListener('DOMContentLoaded', () => {
    const rowsInput = document.getElementById('rows');
    const columnsInput = document.getElementById('columns');
    const generateTableButton = document.getElementById('generateTable');
    const dynamicTable = document.getElementById('dynamicTable');

    generateTableButton.addEventListener('click', () => {
        const rows = parseInt(rowsInput.value);
        const columns = parseInt(columnsInput.value);

    
       
        dynamicTable.innerHTML = '';

        for (let i = 0; i < rows; i++) {
            const row = document.createElement('tr');
            for (let j = 0; j < columns; j++) {
                const cell = document.createElement('td');
                cell.textContent = `행 ${i + 1}, 열 ${j + 1}`;
                row.appendChild(cell);
            }
            dynamicTable.appendChild(row);
        }
    });
});