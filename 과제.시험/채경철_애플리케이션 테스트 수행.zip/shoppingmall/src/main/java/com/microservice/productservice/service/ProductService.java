package com.microservice.productservice.service;

import com.microservice.productservice.entity.Product;
import com.microservice.productservice.payload.request.ProductRequest;
import com.microservice.productservice.payload.response.ProductResponse;

import java.util.List;

public interface ProductService {
    long addProduct(ProductRequest productRequest);
    ProductResponse getProductById(long productId);
    List<ProductResponse> getAllProducts();
    void reduceQuantity(long productId, long quantity);
    void deleteProductById(long productId);
}