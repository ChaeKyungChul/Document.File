$(function(){
  $("#content").summernote({
    placeholder:"내용",
    tabsize:2,
    height:300,
    lang: 'ko-KR'
    });
  });