package jspboard.ado;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.ArrayList;

import jspboard.ado.dto.BDto;

public class JBoardDao {
	 
	   PreparedStatement pstmt = null;
	   Statement stmt = null;
	   ResultSet res = null;
	   Connection conn;
	   
	    public JBoardDao(Connection conn) {
	       this.conn = conn;
	    }
	    
       //select
	 public ArrayList<BDto> selectDB(){
	       
	       ArrayList<BDto> dtos = new ArrayList<>();
	   
	       String sql = "SELECT name FROM country"
	             + " limit ?, ?";

	       try {
	         pstmt = conn.prepareStatement(sql);
	        
	         pstmt.setInt(1, 0);
	         pstmt.setInt(2, 20);
	         System.out.println(pstmt);     
	         res = pstmt.executeQuery();
	       
	         while(res.next()) {
	           
	           String name = res.getString("name");
	           
	           BDto bDto = new BDto();
	           bDto.setName(name);
	           dtos.add(bDto);
	         }
	       } catch(SQLException e) {
	          e.printStackTrace();
	       } finally {
	          try {
	             if(res != null) res.close();
	             if(pstmt != null) pstmt.close();
	          }catch(SQLException e) {e.printStackTrace();}   
	       }
	       
	       return dtos;
	    }
	    
	
	    
	}
