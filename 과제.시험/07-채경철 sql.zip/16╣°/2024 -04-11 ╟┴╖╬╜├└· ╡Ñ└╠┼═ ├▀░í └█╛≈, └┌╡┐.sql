/* 2024-04-11 시험  */
use world;
select * 
from  city;
/*자동으로 데이터를 추가하는 방법 중 하나는 저장 프로시저를 사용하는 것입니다.*/
DELIMITER //
CREATE PROCEDURE City(in id int,
				      IN Name char (35),
					  IN countryCode char (3),
					  IN district char (20), 
					  IN Population INT)
BEGIN
    INSERT INTO City (id, Name, CountryCode, district, Population) 
    VALUES (id, Name, countryCode, district, Population);
END //
DELIMITER ;

/*이제 위의 저장 프로시저를 생성하면, 저장 프로시저를 호출하여 입력한 정보로 데이터를 자동으로 추가할 수 있습니다*/
/*방법*/
CALL City('1001', 'test01', 'KOR', 'test011', '10000000');
CALL City('1002', 'test02', 'KOR', 'test021', '20000000');
CALL City('1003', 'test03', 'KOR', 'test031', '30000000');
CALL City('1004', 'test04', 'KOR', 'test041', '40000000');
select * 
from City;
delete from city where id=1001;
drop PROCEDURE city;
