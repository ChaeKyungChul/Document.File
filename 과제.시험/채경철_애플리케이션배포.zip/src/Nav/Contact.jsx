import React from 'react'

const Contact = () => {
  return (
    <div id="contact">Contact</div>
  )
}

export default Contact