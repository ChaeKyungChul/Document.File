import React from 'react'

const Project = () => {
  return (
    <div id="project">Project</div>
  )
}

export default Project